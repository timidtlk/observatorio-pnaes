CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- 1º: Configuração dos membros (Insira os membros que você quer que inicializem com a aplicação)

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Michelli Daros', 
    'É a pesquisadora que coordena a pesquisa Dez anos da Lei 12.711/2012 e doze anos de Programa Nacional de Assistência Estudantil (PNAES): para onde caminham as políticas de acesso-permanência do IFSP?. Atua como docente do curso de Serviço Social da Universidade Estadual de Maringá (UEM). Trabalhou como assistente social no Instituto Federal de Educação, Ciência e Tecnologia de São Paulo por 13 anos. Doutora e mestra em Serviço Social pela Pontifícia Universidade Católica de São Paulo (PUC-SP).', 
    'madaros@uem.br', 
    'https://lattes.cnpq.br/5302225212286596',
    'michelli',
    '$2a$12$vDfmpZg0klTIDEN7x9.4X.HwPFDC1bWCaLLWWmSvXlQpX2b4FoQ7u',
    'MEMBER',
    'michelli.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Michelli Daros');

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Giselly Barros', 
    'É mulher preta e periférica da zona norte de São Paulo, neta de Liondina e filha de Vitalina, Urbanista e Arquiteta, Doutora em Arquitetura e Urbanismo, professora e pesquisadora no Instituto Federal de São Paulo (IFSP) – campus São Paulo, onde atua também como integrante do NEABI – Núcleo de Estudos Afro-Brasileiros e Indígenas. Também lidera o GEPRETAS, grupo de pesquisa que investiga as relações étnico-raciais no território, na arquitetura e na sociedade. Sua atuação se dá nos campos do ensino, da pesquisa e da extensão, com temas como espaços públicos e privados de uso público, relações étnico-raciais, paisagem, memória e pertencimento.', 
    'giselly.barros@ifsp.edu.br', 
    'https://lattes.cnpq.br/6485805298131356',
    'giselly',
    '$2a$12$.EF72VoijTDHqjFbXMRFUu1KggWelcyNgMZWcb1IhotN0G1oMia0W',
    'MEMBER',
    'giselly.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Giselly Barros');

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Thaís Esteves', 
    'Trabalha como Assistente Social na área da Educação, no Instituto Federal de Educação, Ciência e Tecnologia de São Paulo (IFSP) – Campus Jacareí, desde 2014. Já atuou em outras políticas públicas e também como professora universitária em curso de Serviço Social. Atualmente, além de participar da pesquisa “Dez anos da Lei 12.711/2012 e doze anos do Programa Nacional de Assistência Estudantil (PNAES): para onde caminham as políticas de acesso-permanência do IFSP?”, integra o Núcleo de Estudos e Pesquisa sobre Identidade (NEPI), vinculado ao Programa de Pós-Graduação em Serviço Social da PUC-SP. É Doutora e Mestra em Serviço Social pela PUC-SP.', 
    'thais.esteves@ifsp.edu.br', 
    'https://lattes.cnpq.br/0424886501131469',
    'thais',
    '$2a$12$CDPPczA5eEo4cDSL8nQG9uP10PoT9yTIADTTT2EveDPPUmTiskh3a',
    'MEMBER',
    'thais.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Thaís Esteves');

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Priscila Aquino', 
    'Compõe a equipe de pesquisa “Dez anos da Lei 12.711/2012 e doze anos do Programa Nacional de Assistência Estudantil (PNAES): para onde caminham as políticas de acesso e permanência no IFSP?”. Também integra o grupo de pesquisa GEPRETAS, que investiga as relações étnico-raciais no território, na arquitetura e na sociedade. <br>É servidora técnico-administrativa há mais de 13 anos no Instituto Federal de Educação, Ciência e Tecnologia de São Paulo (IFSP), tendo atuado, em grande parte desse período, na Pró-Reitoria de Extensão. É mestre em Ciências pelo Programa de Mudança Social e Participação Política da Universidade de São Paulo (USP). ', 
    'aquino.priscila@ifsp.edu.br', 
    'https://lattes.cnpq.br/3851258432036532',
    'priscila',
    '$2a$12$aJi7HUqMVCivI6slT8cH9u5PusmU0TDGzUMsQFzPtou0QkDx5lhWm',
    'MEMBER',
    'priscila.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Priscila Aquino');

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Sérgio Bastos', 
    'Bolsista de pesquisa no Instituto Federal de Educação, Ciência e Tecnologia de São Paulo (IFSP). Estudante do curso de Ciência da Computação. Atua no projeto "Dez anos da Lei 12.711/2012 e doze anos de Programa Nacional de Assistência Estudantil (PNAES): para onde caminham as políticas de acesso-permanência do IFSP?", sendo responsável pela filtragem e tratamento dos dados.', 
    's.bastos@aluno.ifsp.edu.br', 
    'https://lattes.cnpq.br/4311392350844092',
    'sergio',
    '$2a$12$onbftxlIm7WaLbk9plPN2.vzVZeHxcVuRhhqnCKm33AaaKu8dHfpW',
    'MEMBER',
    'sergio.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Sérgio Bastos');

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Nathália Lopes Caldeira Brant', 
    'Compõe a equipe de pesquisa “Dez anos da Lei 12.711/2012 e doze anos do Programa Nacional de Assistência Estudantil (PNAES): para onde caminham as políticas de acesso e permanência no IFSP?”. Desde 2011 é assistente social no IFSULDEMINAS Campus Machado, trabalhando com permanência estudantil, alimentação escolar, educação do campo e educação inclusiva. Co-coordenadora do Núcleo de Estudos em Agroecologia e Produção Orgânica (NEAPO) do IFSULDEMINAS-Campus Machado. Participante dos seguintes grupos de estudo e pesquisa: Grupo de Estudos e Pesquisas Marxistas (GEPEM) e Núcleo de Estudo sobre Trabalho, Agroecologia e Segurança Alimentar (NETASA). Graduada e Mestre em Serviço Social pela UNESP-Franca e Doutora em Serviço Social pela PUC pela Pontifícia Universidade Católica de São Paulo (PUC-SP).', 
    'nathalia.brant@ifsuldeminas.edu.br', 
    'https://lattes.cnpq.br/8824968948902788',
    'nathalia',
    '$2a$12$6mVDIR3od1bONbnP/g/0pefd3HboX9EPjmTy2DVGCRbRHlsgIHCsK',
    'MEMBER',
    'nathalia.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Nathália Lopes Caldeira Brant');

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Guilherme Ramalho Arduini', 
    'Docente da educação básica, superior e pós-graduação no Instituto Federal de Educação de São Paulo (IFSP), Campus Hortolândia. Pesquisador convidado pela Universidade Paris-Nanterre para o ano letivo 2024-2025. Líder do grupo "Laicidade, igrejas e educação pública no Brasil contemporâneo". Membro da Associação de Cientistas Sociais da Religião da América Latina, do Laboratório de Antropologia da Religião (LAR-Unicamp), do Núcleo Interdisciplinar de Estudos e Pesquisas em História da Educação (USP), da Rede História e Catolicismo (UFRN/UFPel/UFMT). Coordenador do projeto CNPq "O papel do Estado Nacional brasileiro na atividade educativa das igrejas cristãs, dos anos 1930 ao presente" (2022-2025). Membro do projeto CNPq Dez anos de Reserva de Vagas (cotas) e doze anos de Programa Nacional de Assistência Estudantil (PNAES): para onde caminham as políticas de acesso-permanência do IFSP? (2023-2026). Membro associado ao Centre de Recherche Amiénois en Éducation et Formation (CAREF) da Université de Picardie Jules Verne - UPJV (França). Realizou seminários na Université de Bordeaux e na UPJV, ambas na França. Possui artigos publicados em periódicos nacionais Qualis A1 e revistas internacionais.', 
    'guilherme.arduini@gmail.com', 
    'https://lattes.cnpq.br/4213387772904874',
    'guilherme',
    '$2a$12$vaaOMSznn..adoJpqvk2YOXU5zZL2hjsqfM3Z03y9UNv70nnssoKu',
    'MEMBER',
    'guilherme.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Guilherme Ramalho Arduini');

INSERT INTO members 
    (id, name, description, email, lattes, login, password, role, photo_url) 
SELECT
    gen_random_uuid(),
    'Maria Borges', 
    'Compõe a equipe de pesquisa “Dez anos da Lei 12.711/2012 e doze anos do Programa Nacional de Assistência Estudantil (PNAES): para onde caminham as políticas de acesso e permanência no IFSP?”. Educadora Popular e assistente social  na Política de Educação, no Instituto Federal de Educação, Ciência e Tecnologia de São Paulo/Campus São Paulo, desde 2013, atuando diretamente com as políticas de assistência estudantil e nos debates sobre permanência estudantil. Doutora e Mestre em Serviço Social pela Pontifícia Universidade Católica de São Paulo (2012) relacionada a linha de pesquisa Serviço Social: Fundamentos, Formação e Trabalho Profissional. Especialista na área de Assistência e Prevenção a pacientes portadores de HIV/Aids pelo Hospital das Clínicas da Faculdade de Medicina da Universidade de São Paulo (2005). Graduada em Serviço Social pela Universidade Estadual Paulista Júlio de Mesquita Filho (2003). Pesquisas nas temáticas de: Serviço Social na Educação, permanência estudantil, educação, políticas de acesso e permanência. Organizadora do Livro Serviço Social e Educação Profissional e Tecnológica, Editora Cortez, 2019.', 
    'mariaborges@ifsp.edu.br', 
    'https://lattes.cnpq.br/6317314315523062',
    'maria',
    '$2a$12$JlkUXekUKaJU.2DN6K8zsO9MBi0aaY3TKtUE49ikXR/L.upb2g0pa',
    'MEMBER',
    'maria.jpg'
WHERE NOT EXISTS
    (SELECT 1 FROM members WHERE name = 'Maria Borges');